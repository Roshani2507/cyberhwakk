
import React, { useState, useEffect } from 'react';
import { Shield, Check, X } from 'lucide-react';
import URLScanner from '@/components/URLScanner';
import ThreatDisplay from '@/components/ThreatDisplay';
import ThreatStatistics from '@/components/ThreatStatistics';
import QuickActions from '@/components/QuickActions';
import ScanHistory from '@/components/ScanHistory';
import { ThreatAnalysis } from '@/utils/threatDetection';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const Index = () => {
  const [scanResult, setScanResult] = useState<ThreatAnalysis | null>(null);
  const [scanHistory, setScanHistory] = useState<ThreatAnalysis[]>([]);
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  
  // Load scan history from local storage on component mount
  useEffect(() => {
    const savedHistory = localStorage.getItem('scanHistory');
    if (savedHistory) {
      try {
        // Parse dates back to Date objects
        const parsed = JSON.parse(savedHistory, (key, value) => {
          if (key === 'timestamp' && value) {
            return new Date(value);
          }
          return value;
        });
        setScanHistory(parsed);
      } catch (error) {
        console.error('Error loading scan history:', error);
      }
    }
  }, []);
  
  // Save scan history to local storage whenever it changes
  useEffect(() => {
    if (scanHistory.length > 0) {
      localStorage.setItem('scanHistory', JSON.stringify(scanHistory));
    }
  }, [scanHistory]);

  const handleScanComplete = (result: ThreatAnalysis) => {
    setScanResult(result);
    // Add to history (avoid duplicates by URL)
    setScanHistory(prevHistory => {
      const exists = prevHistory.some(item => item.url === result.url);
      if (exists) {
        return [
          result, 
          ...prevHistory.filter(item => item.url !== result.url)
        ];
      }
      return [result, ...prevHistory].slice(0, 20); // Keep last 20 scans
    });
  };

  const handleSelectHistoryItem = (item: ThreatAnalysis) => {
    setScanResult(item);
    setIsSheetOpen(false);
  };

  const handleClearHistory = () => {
    setScanHistory([]);
    localStorage.removeItem('scanHistory');
  };

  const handleScanExample = (url: string) => {
    // Fill the URLScanner input with the example URL
    const inputElement = document.querySelector('input[type="text"]') as HTMLInputElement;
    if (inputElement) {
      inputElement.value = url;
      // Trigger a change event to update the internal state
      const event = new Event('change', { bubbles: true });
      inputElement.dispatchEvent(event);
      
      // Find and click the scan button
      const scanButton = document.querySelector('button:has(.h-4.w-4)') as HTMLButtonElement;
      if (scanButton) {
        scanButton.click();
      }
    }
  };

  return (
    <div className="min-h-screen bg-security-bg security-pattern">
      <header className="container mx-auto pt-8 pb-6 md:pt-12 md:pb-8 animate-fade-slide-in">
        <div className="flex items-center justify-center mb-4">
          <div className="bg-security-accent/10 p-3 rounded-full border border-security-accent/30 animate-pulse-glow">
            <Shield className="h-6 w-6 md:h-8 md:w-8 text-security-accent" />
          </div>
        </div>
        <h1 className="text-2xl md:text-3xl font-bold text-center mb-2">CyberHawk</h1>
        <p className="text-center text-muted-foreground max-w-xl mx-auto px-4 text-sm md:text-base">
          AI-powered threat detection for ecommerce links. 
          Protect yourself from scams, phishing attempts, and malicious websites.
        </p>
      </header>

      <main className="container mx-auto px-4">
        <div className="flex flex-col items-center">
          <URLScanner onScanComplete={handleScanComplete} />
          
          <div className="w-full max-w-3xl mt-3 flex justify-end">
            <Sheet open={isSheetOpen} onOpenChange={setIsSheetOpen}>
              <SheetTrigger asChild>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="bg-secondary/50 border-secondary hover:bg-secondary"
                >
                  {scanHistory.length > 0 ? (
                    <>History ({scanHistory.length})</>
                  ) : (
                    <>History</>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent className="w-full max-w-md">
                <div className="mt-6 pr-6">
                  <ScanHistory 
                    history={scanHistory} 
                    onSelect={handleSelectHistoryItem}
                    onClear={handleClearHistory}
                  />
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Features Overview Section when no scan result */}
        {!scanResult && (
          <div className="mt-8 md:mt-12 mb-8 text-center animate-fade-slide-in">
            <h2 className="text-xl md:text-2xl font-bold mb-6">Key Security Features</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 max-w-5xl mx-auto">
              <Card className="bg-card/50 border-secondary shadow-sm hover:shadow transition-all duration-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Shield className="h-5 w-5 text-security-accent" />
                    Threat Detection
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Advanced AI analysis identifies phishing attempts, malware, scams, and 
                    other security threats in ecommerce links.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-card/50 border-secondary shadow-sm hover:shadow transition-all duration-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Check className="h-5 w-5 text-security-safe" />
                    Recommendations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Get personalized security recommendations based on detected threats 
                    to keep your information and devices safe.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-card/50 border-secondary shadow-sm hover:shadow transition-all duration-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <X className="h-5 w-5 text-security-high" />
                    Threat Statistics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    View detailed statistics about detected threats, including common threat
                    types and risk level distribution.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
        
        {/* Two-column layout for scan results when available */}
        {scanResult && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-8 mb-8 md:mb-12">
            <div className="lg:col-span-2">
              <ThreatDisplay threatAnalysis={scanResult} />
            </div>
            
            <div className="lg:col-span-1 space-y-4">
              {/* Quick Actions Panel */}
              <Card className="bg-card/50 border-secondary shadow-sm hover:shadow transition-all duration-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Quick Actions</CardTitle>
                  <CardDescription>Common security operations</CardDescription>
                </CardHeader>
                <CardContent>
                  <QuickActions onScanExample={handleScanExample} />
                </CardContent>
              </Card>
              
              {/* Threat Summary Panel - Shows key threat info at a glance */}
              <Card className="bg-card/50 border-secondary shadow-sm hover:shadow transition-all duration-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Threat Summary</CardTitle>
                  <CardDescription>At a glance security information</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-3 bg-secondary/30 rounded-md">
                      <p className="text-xs text-muted-foreground">Threat Level</p>
                      <p className={`text-sm font-medium ${
                        scanResult.threatLevel === 'high' ? 'text-security-high' :
                        scanResult.threatLevel === 'medium' ? 'text-security-medium' :
                        scanResult.threatLevel === 'low' ? 'text-security-low' :
                        'text-security-safe'
                      }`}>
                        {scanResult.threatLevel.toUpperCase()}
                      </p>
                    </div>
                    <div className="p-3 bg-secondary/30 rounded-md">
                      <p className="text-xs text-muted-foreground">Confidence</p>
                      <p className="text-sm font-medium">{scanResult.confidence}%</p>
                    </div>
                  </div>
                  
                  {scanResult.threatTypes.length > 0 && (
                    <div>
                      <p className="text-xs text-muted-foreground mb-2">Detected Threats</p>
                      <div className="flex flex-wrap gap-1">
                        {scanResult.threatTypes.map(type => (
                          <span 
                            key={type}
                            className="text-xs px-2 py-1 bg-secondary/50 rounded-full"
                          >
                            {type.split('-').map(word => 
                              word.charAt(0).toUpperCase() + word.slice(1)
                            ).join(' ')}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        )}
        
        {/* Show statistics when there's history data */}
        {scanHistory.length > 0 && (
          <div className="mb-8 md:mb-12">
            <ThreatStatistics history={scanHistory} />
          </div>
        )}
        
        {!scanResult && scanHistory.length === 0 && (
          <div className="w-full max-w-3xl mt-6 md:mt-8 grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mx-auto">
            <div className="mt-4 md:mt-8 text-center md:text-left animate-fade-slide-in" style={{ animationDelay: '0.1s' }}>
              <div className="mb-4 opacity-50 md:mx-0 mx-auto w-fit">
                <Shield className="h-12 w-12 md:h-16 md:w-16" />
              </div>
              <h3 className="text-lg font-medium mb-1">No Recent Scans</h3>
              <p className="text-sm text-muted-foreground">
                Enter a URL above to scan for potential threats. Our AI will analyze the link
                and provide a security assessment.
              </p>
            </div>
            
            <div className="animate-fade-slide-in" style={{ animationDelay: '0.2s' }}>
              <QuickActions onScanExample={handleScanExample} />
            </div>
          </div>
        )}
      </main>
      
      <footer className="mt-10 md:mt-16 py-6 border-t border-border/20">
        <div className="container mx-auto text-center text-xs text-muted-foreground">
          <p>CyberHawk eCommerce Security Shield &copy; 2025</p>
          <p className="mt-1">Protecting online shoppers with advanced threat detection</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
