
export type ThreatLevel = 'high' | 'medium' | 'low' | 'safe';

export type ThreatType = 
  | 'phishing'
  | 'malware'
  | 'scam'
  | 'fraud'
  | 'spoofing'
  | 'counterfeit'
  | 'information-theft'
  | 'suspicious'
  | 'unknown';

export interface ThreatAnalysis {
  url: string;
  threatLevel: ThreatLevel;
  threatTypes: ThreatType[];
  confidence: number;
  timestamp: Date;
  details: string;
  isSafe: boolean;
}

// Mock AI threat detection function - in a real application this would call an API
export const analyzeUrl = (url: string): Promise<ThreatAnalysis> => {
  return new Promise((resolve) => {
    // Simulate API call delay
    setTimeout(() => {
      // These patterns are for demonstration only
      const knownThreats: Record<string, { level: ThreatLevel, types: ThreatType[], details: string }> = {
        'scam': { 
          level: 'high', 
          types: ['scam', 'fraud'], 
          details: 'This URL matches patterns of known scam sites targeting ecommerce customers.'
        },
        'phishing': { 
          level: 'high', 
          types: ['phishing', 'information-theft'], 
          details: 'This URL appears to be a phishing attempt designed to steal login credentials.'
        },
        'malware': { 
          level: 'high', 
          types: ['malware'], 
          details: 'This URL likely hosts malicious software that can harm your device.'
        },
        'spoofed': { 
          level: 'medium', 
          types: ['spoofing'], 
          details: 'This URL appears to be mimicking a legitimate ecommerce site.'
        },
        'counterfeit': { 
          level: 'medium', 
          types: ['counterfeit', 'fraud'], 
          details: 'This URL is likely selling counterfeit products.'
        },
        'suspicious': { 
          level: 'low', 
          types: ['suspicious'], 
          details: 'This URL contains unusual patterns that warrant caution.'
        }
      };

      // For demo purposes, check for keywords in URL to determine threat
      const lowerUrl = url.toLowerCase();
      
      let result: ThreatAnalysis;
      
      if (lowerUrl.includes('scam') || lowerUrl.includes('free-gift')) {
        const threat = knownThreats['scam'];
        result = createThreatResult(url, threat.level, threat.types, 94, threat.details, false);
      } 
      else if (lowerUrl.includes('phish') || lowerUrl.includes('login') && lowerUrl.includes('secure')) {
        const threat = knownThreats['phishing'];
        result = createThreatResult(url, threat.level, threat.types, 92, threat.details, false);
      } 
      else if (lowerUrl.includes('download') || lowerUrl.includes('exe')) {
        const threat = knownThreats['malware'];
        result = createThreatResult(url, threat.level, threat.types, 97, threat.details, false);
      } 
      else if (lowerUrl.includes('cheap') || lowerUrl.includes('discount') && lowerUrl.includes('brand')) {
        const threat = knownThreats['counterfeit'];
        result = createThreatResult(url, threat.level, threat.types, 86, threat.details, false);
      } 
      else if (lowerUrl.includes('amaz0n') || lowerUrl.includes('paypa1')) {
        const threat = knownThreats['spoofed'];
        result = createThreatResult(url, threat.level, threat.types, 88, threat.details, false);
      } 
      else if (lowerUrl.includes('deal') || lowerUrl.includes('offer') || Math.random() > 0.7) {
        const threat = knownThreats['suspicious'];
        result = createThreatResult(url, threat.level, threat.types, 65, threat.details, false);
      } 
      else {
        result = createThreatResult(
          url, 
          'safe', 
          [], 
          99, 
          'This URL appears to be safe based on our analysis.', 
          true
        );
      }
      
      resolve(result);
    }, 1500); // 1.5 second delay to simulate processing
  });
};

const createThreatResult = (
  url: string,
  threatLevel: ThreatLevel,
  threatTypes: ThreatType[],
  confidence: number,
  details: string,
  isSafe: boolean
): ThreatAnalysis => {
  return {
    url,
    threatLevel,
    threatTypes,
    confidence,
    timestamp: new Date(),
    details,
    isSafe
  };
};
