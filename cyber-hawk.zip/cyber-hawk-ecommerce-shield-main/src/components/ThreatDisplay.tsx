
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ThreatAnalysis, ThreatType } from '@/utils/threatDetection';
import SecurityBadge from './SecurityBadge';
import { cn } from '@/lib/utils';
import { Link, AlertTriangle, Info, CheckCheck, ShieldCheck, ShieldAlert, ShieldOff } from 'lucide-react';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface ThreatDisplayProps {
  threatAnalysis: ThreatAnalysis | null;
}

const ThreatDisplay: React.FC<ThreatDisplayProps> = ({ threatAnalysis }) => {
  const [activeTab, setActiveTab] = useState('details');
  
  if (!threatAnalysis) return null;

  const { url, threatLevel, threatTypes, confidence, details, isSafe } = threatAnalysis;

  const getThreatLevelInfo = () => {
    switch (threatLevel) {
      case 'high':
        return {
          title: 'High Risk',
          description: 'This link poses a serious security threat. Do not proceed.',
          color: 'border-security-high bg-security-high/5 text-security-high',
          icon: ShieldAlert
        };
      case 'medium':
        return {
          title: 'Medium Risk',
          description: 'This link shows concerning patterns. Proceed with caution.',
          color: 'border-security-medium bg-security-medium/5 text-security-medium',
          icon: ShieldOff
        };
      case 'low':
        return {
          title: 'Low Risk',
          description: 'This link has minor issues. Use with some caution.',
          color: 'border-security-low bg-security-low/5 text-security-low',
          icon: ShieldOff
        };
      case 'safe':
        return {
          title: 'Safe',
          description: 'This link appears to be safe based on our analysis.',
          color: 'border-security-safe bg-security-safe/5 text-security-safe',
          icon: ShieldCheck
        };
      default:
        return {
          title: 'Unknown',
          description: 'We could not determine the safety of this link.',
          color: 'border-muted-foreground',
          icon: Info
        };
    }
  };

  const threatInfo = getThreatLevelInfo();
  
  const getConfidenceColor = () => {
    if (confidence >= 90) return "text-security-safe";
    if (confidence >= 70) return "text-security-low";
    if (confidence >= 50) return "text-security-medium";
    return "text-security-high";
  };
  
  const getThreatTypeBadgeColor = (type: ThreatType) => {
    switch (type) {
      case 'phishing':
      case 'malware':
      case 'fraud':
      case 'information-theft':
        return 'bg-security-high/20 text-security-high border-security-high/30';
      case 'spoofing':
      case 'counterfeit':
        return 'bg-security-medium/20 text-security-medium border-security-medium/30';
      case 'suspicious':
      case 'unknown':
        return 'bg-security-low/20 text-security-low border-security-low/30';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getThreatTypeDescription = (type: ThreatType) => {
    switch (type) {
      case 'phishing':
        return 'Attempts to steal credentials or personal information by mimicking legitimate sites';
      case 'malware':
        return 'May contain harmful software that can damage your system or steal information';
      case 'scam':
        return 'Designed to trick users into making payments or revealing information';
      case 'fraud':
        return 'Offers fake goods or services to defraud consumers';
      case 'spoofing':
        return 'Impersonates legitimate websites with similar-looking URLs';
      case 'counterfeit':
        return 'Sells fake products that look like name-brand goods';
      case 'information-theft':
        return 'Designed to collect personal or financial information illegally';
      case 'suspicious':
        return 'Contains unusual patterns that may indicate security risks';
      default:
        return 'Unidentified threat type';
    }
  };

  const getRecommendations = () => {
    if (isSafe) {
      return [
        "This URL appears safe to visit",
        "Always verify the site's security before making purchases",
        "Check for HTTPS and valid certificates"
      ];
    }

    const recommendations = [
      "Do not enter personal information on this site",
      "Avoid downloading files from this URL",
      "Do not make purchases through this link"
    ];

    if (threatLevel === 'high') {
      recommendations.push("Close this site immediately");
      recommendations.push("Run a security scan on your device if you've already visited");
    }

    if (threatTypes.includes('phishing') || threatTypes.includes('information-theft')) {
      recommendations.push("Change your passwords if you've already entered them");
    }

    if (threatTypes.includes('malware')) {
      recommendations.push("Update your antivirus software");
    }

    return recommendations;
  };

  return (
    <Card className="w-full max-w-3xl mt-8 border-secondary bg-card/50 card-hover-effect animate-fade-slide-in">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-xl font-semibold">Scan Results</CardTitle>
            <CardDescription>
              Analysis for the provided URL
            </CardDescription>
          </div>
          <SecurityBadge level={threatLevel} size={28} className="animate-float" />
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="flex items-center space-x-2 mb-4 p-2 bg-background/50 rounded-md">
          <Link className="text-primary" size={18} />
          <span className="text-sm font-mono truncate">{url}</span>
        </div>
        
        <Alert className={cn("mb-4 border", threatInfo.color)}>
          <threatInfo.icon className={cn("h-4 w-4", !isSafe && "animate-pulse")} />
          <AlertTitle>{threatInfo.title}</AlertTitle>
          <AlertDescription>
            {threatInfo.description}
          </AlertDescription>
        </Alert>
        
        <Tabs defaultValue="details" className="mt-4" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="threats">Threats</TabsTrigger>
            <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          </TabsList>
          
          <TabsContent value="details" className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1">
                <h4 className="text-sm font-medium">Analysis Confidence:</h4>
                <span className={cn("text-sm font-medium", getConfidenceColor())}>
                  {confidence}%
                </span>
              </div>
              <Progress 
                value={confidence} 
                className={cn(
                  "h-2", 
                  confidence >= 90 ? "bg-security-safe/30" : 
                  confidence >= 70 ? "bg-security-low/30" : 
                  confidence >= 50 ? "bg-security-medium/30" : 
                  "bg-security-high/30"
                )}
              />
            </div>
            <div>
              <h4 className="text-sm font-medium mb-2">Details:</h4>
              <p className="text-sm text-muted-foreground">{details}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium mb-2">URL Analysis:</h4>
              <div className="grid grid-cols-2 gap-2">
                <div className="px-3 py-2 bg-secondary/30 rounded-md">
                  <p className="text-xs text-muted-foreground">Domain</p>
                  <p className="text-sm font-mono">
                    {new URL(url.startsWith('http') ? url : `https://${url}`).hostname}
                  </p>
                </div>
                <div className="px-3 py-2 bg-secondary/30 rounded-md">
                  <p className="text-xs text-muted-foreground">Protocol</p>
                  <p className="text-sm font-mono">
                    {url.startsWith('https') ? 'HTTPS (Secure)' : 'HTTP (Not Secure)'}
                  </p>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="threats">
            {threatTypes.length > 0 ? (
              <div className="space-y-3">
                {threatTypes.map((type) => (
                  <div 
                    key={type} 
                    className={cn(
                      "p-3 rounded-md border", 
                      getThreatTypeBadgeColor(type)
                    )}
                  >
                    <div className="flex items-center mb-1">
                      <AlertTriangle className="h-3.5 w-3.5 mr-1.5" />
                      <h4 className="text-sm font-medium">
                        {type.split('-').map(word => 
                          word.charAt(0).toUpperCase() + word.slice(1)
                        ).join(' ')}
                      </h4>
                    </div>
                    <p className="text-xs ml-5">
                      {getThreatTypeDescription(type)}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 bg-security-safe/5 border border-security-safe/20 rounded-md flex items-start">
                <CheckCheck className="text-security-safe h-5 w-5 mr-2 mt-0.5" />
                <div>
                  <h4 className="text-security-safe font-medium">No Threats Detected</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    Our scan did not find any suspicious patterns in this URL.
                  </p>
                </div>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="recommendations">
            <div>
              <h4 className="text-sm font-medium mb-2">Security Recommendations:</h4>
              <ul className="space-y-2">
                {getRecommendations().map((rec, index) => (
                  <li 
                    key={index}
                    className="flex items-center gap-2 p-2 bg-secondary/20 rounded-md"
                  >
                    {isSafe ? (
                      <ShieldCheck className="h-4 w-4 text-security-safe flex-shrink-0" />
                    ) : (
                      <ShieldAlert className="h-4 w-4 text-security-high flex-shrink-0" />
                    )}
                    <span className="text-sm">{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default ThreatDisplay;
