
import React, { useState, useRef } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Shield, X, Check } from 'lucide-react';
import { toast } from '@/components/ui/sonner';
import { analyzeUrl, ThreatAnalysis } from '@/utils/threatDetection';

interface URLScannerProps {
  onScanComplete: (result: ThreatAnalysis) => void;
}

const URLScanner: React.FC<URLScannerProps> = ({ onScanComplete }) => {
  const [url, setUrl] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUrl(e.target.value);
    setError('');
  };

  const clearInput = () => {
    setUrl('');
    setError('');
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const validateUrl = (url: string): boolean => {
    try {
      // Simple validation - just check it's formatted like a URL
      const pattern = /^(https?:\/\/)?([\da-z.-]+)\.([a-z.]{2,})([\/\w .-]*)*\/?$/;
      return pattern.test(url);
    } catch (e) {
      return false;
    }
  };

  const handleScan = async () => {
    if (!url) {
      setError('Please enter a URL to scan');
      return;
    }

    if (!validateUrl(url)) {
      setError('Please enter a valid URL');
      return;
    }

    setIsScanning(true);
    setError('');

    try {
      toast('Scanning URL for threats...', {
        description: 'Our AI is analyzing this link for potential security risks.',
      });

      const result = await analyzeUrl(url);
      
      onScanComplete(result);
      
      if (!result.isSafe) {
        toast(`${result.threatLevel.toUpperCase()} risk detected!`, {
          description: result.details,
          duration: 5000,
        });
      } else {
        toast('URL appears safe', {
          description: 'No threats were detected in this URL.',
          icon: <Check className="h-4 w-4 text-security-safe" />
        });
      }
    } catch (error) {
      console.error('Error during scan:', error);
      setError('An error occurred during scanning. Please try again.');
      toast.error('Scan failed', {
        description: 'There was a problem analyzing this URL.',
        icon: <X className="h-4 w-4" />
      });
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="w-full max-w-3xl animate-fade-slide-in">
      <div className="mb-3 text-center">
        <h2 className="text-xl font-medium">URL Threat Scanner</h2>
        <p className="text-sm text-muted-foreground">
          Enter an ecommerce link to analyze for potential threats
        </p>
      </div>

      <div className={cn(
        "relative flex items-center mt-4 transition-all",
        isScanning && "scanning-animation"
      )}>
        <Input
          ref={inputRef}
          type="text"
          placeholder="https://example.com/product"
          className={cn(
            "pr-20 pl-10 py-5 sm:py-6 text-base bg-secondary/50 border-secondary focus-visible:ring-primary/70",
            error && "border-security-high focus-visible:ring-security-high",
            isScanning && "animate-pulse"
          )}
          value={url}
          onChange={handleInputChange}
          disabled={isScanning}
          onKeyDown={(e) => e.key === 'Enter' && handleScan()}
        />
        
        <Shield 
          className={cn(
            "absolute left-3 text-primary", 
            isScanning && "animate-pulse"
          )} 
          size={20} 
        />
        
        {url && (
          <X
            className="absolute right-[5.5rem] hover:text-muted-foreground cursor-pointer"
            size={18}
            onClick={clearInput}
          />
        )}
        
        <Button
          className={cn(
            "absolute right-1 bg-primary hover:bg-primary/80 text-white"
          )}
          size="sm"
          onClick={handleScan}
          disabled={isScanning}
        >
          {isScanning ? (
            <>
              <Search className="mr-1 h-4 w-4 animate-pulse" />
              Scanning...
            </>
          ) : (
            <>
              <Search className="mr-1 h-4 w-4" />
              Scan
            </>
          )}
        </Button>
      </div>
      
      {error && (
        <div className="mt-2 text-security-high text-sm animate-fade-slide-in">
          {error}
        </div>
      )}
      
      <div className="mt-2 text-xs text-muted-foreground">
        Try scanning URLs containing words like 'scam', 'free-gift', 'phish', 'cheap' to see different threat responses
      </div>
    </div>
  );
};

export default URLScanner;
