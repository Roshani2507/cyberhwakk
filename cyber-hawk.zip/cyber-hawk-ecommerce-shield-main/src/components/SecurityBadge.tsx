
import React from 'react';
import { cn } from '@/lib/utils';
import { Shield, ShieldAlert, ShieldCheck, ShieldOff } from 'lucide-react';
import { ThreatLevel } from '@/utils/threatDetection';

interface SecurityBadgeProps {
  level: ThreatLevel;
  className?: string;
  size?: number;
}

const SecurityBadge: React.FC<SecurityBadgeProps> = ({ 
  level, 
  className,
  size = 24
}) => {
  const getBadgeContent = () => {
    switch (level) {
      case 'high':
        return {
          icon: ShieldAlert,
          color: 'text-security-high',
          bg: 'bg-security-high/10',
          border: 'border-security-high/50',
        };
      case 'medium':
        return {
          icon: ShieldAlert,
          color: 'text-security-medium',
          bg: 'bg-security-medium/10',
          border: 'border-security-medium/50',
        };
      case 'low':
        return {
          icon: ShieldOff,
          color: 'text-security-low',
          bg: 'bg-security-low/10',
          border: 'border-security-low/50',
        };
      case 'safe':
      default:
        return {
          icon: ShieldCheck,
          color: 'text-security-safe',
          bg: 'bg-security-safe/10',
          border: 'border-security-safe/50',
        };
    }
  };

  const { icon: Icon, color, bg, border } = getBadgeContent();

  return (
    <div className={cn(
      'flex items-center justify-center rounded-full p-2', 
      bg, 
      border, 
      'border', 
      className
    )}>
      <Icon className={cn(color)} size={size} />
    </div>
  );
};

export default SecurityBadge;
