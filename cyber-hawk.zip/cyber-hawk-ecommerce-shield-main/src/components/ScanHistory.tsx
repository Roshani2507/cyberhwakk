
import React from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Link, Clock, Trash2 } from 'lucide-react';
import SecurityBadge from './SecurityBadge';
import { ThreatAnalysis, ThreatLevel } from '@/utils/threatDetection';

interface ScanHistoryProps {
  history: ThreatAnalysis[];
  onSelect: (item: ThreatAnalysis) => void;
  onClear: () => void;
}

const ScanHistory: React.FC<ScanHistoryProps> = ({ 
  history, 
  onSelect,
  onClear
}) => {
  if (!history.length) {
    return (
      <div className="bg-card/50 rounded-lg p-6 border border-secondary/50 text-center">
        <Clock className="mx-auto h-10 w-10 text-muted-foreground mb-2 opacity-50" />
        <h3 className="text-lg font-medium">No Scan History</h3>
        <p className="text-sm text-muted-foreground mt-1">
          Your previous scan results will appear here.
        </p>
      </div>
    );
  }

  const formatTime = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      hour: 'numeric',
      minute: 'numeric',
      hour12: true
    }).format(date);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">Scan History</h3>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={onClear}
          className="h-8 text-muted-foreground hover:text-destructive"
        >
          <Trash2 className="h-4 w-4 mr-1" /> Clear
        </Button>
      </div>
      
      <ScrollArea className="h-[320px] pr-4">
        <div className="space-y-3">
          {history.map((item, index) => (
            <div
              key={index}
              onClick={() => onSelect(item)}
              className={cn(
                "p-3 rounded-md flex items-center justify-between",
                "bg-secondary/30 hover:bg-secondary/70 border border-secondary/50",
                "cursor-pointer transition-all duration-200 hover:scale-[1.02]"
              )}
            >
              <div className="flex items-center">
                <SecurityBadge level={item.threatLevel} size={18} />
                <div className="ml-3">
                  <div className="flex items-center mb-1">
                    <Link className="h-3 w-3 text-primary mr-1" />
                    <span className="text-xs font-mono truncate max-w-[150px]">
                      {item.url.replace(/(^\w+:|^)\/\//, '')}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {item.threatTypes.length > 0 ? (
                      <Badge variant="outline" className="text-[9px] font-normal py-0 h-4">
                        {item.threatTypes[0].split('-').map(word => 
                          word.charAt(0).toUpperCase() + word.slice(1)
                        ).join(' ')}
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-security-safe/10 text-security-safe text-[9px] font-normal py-0 h-4">
                        Safe
                      </Badge>
                    )}
                    <span className="text-[10px] text-muted-foreground">
                      {formatTime(item.timestamp)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};

export default ScanHistory;
