
import React from 'react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { ShieldCheck, ShieldAlert, Search } from 'lucide-react';

interface QuickActionsProps {
  onScanExample: (url: string) => void;
}

const QuickActions: React.FC<QuickActionsProps> = ({ onScanExample }) => {
  const examples = [
    {
      name: 'Safe Example',
      url: 'https://example-shop.com/product/123',
      icon: ShieldCheck,
      description: 'Legitimate store URL',
      color: 'text-security-safe'
    },
    {
      name: 'Suspicious Example',
      url: 'https://amazn-deals-cheap.com/discount',
      icon: ShieldAlert,
      description: 'Potentially misleading URL',
      color: 'text-security-medium'
    },
    {
      name: 'Phishing Example',
      url: 'https://amaz0n-account-verify-phishing.com',
      icon: ShieldAlert,
      description: 'Known phishing pattern',
      color: 'text-security-high'
    }
  ];

  return (
    <div className="space-y-3">
      <h3 className="text-lg font-medium">Quick Scan Examples</h3>
      <div className="grid gap-3">
        {examples.map((example, index) => (
          <Button
            key={index}
            variant="outline"
            className={cn(
              "flex items-start justify-between h-auto py-3 px-4",
              "bg-secondary/30 hover:bg-secondary/70 border-secondary/50",
              "transition-all duration-200 hover:scale-[1.02]"
            )}
            onClick={() => onScanExample(example.url)}
          >
            <div className="flex items-center">
              <div className={cn(
                "p-1.5 rounded-full mr-3",
                example.color === 'text-security-safe' ? "bg-security-safe/10" : 
                example.color === 'text-security-medium' ? "bg-security-medium/10" : 
                "bg-security-high/10"
              )}>
                <example.icon className={cn("h-3.5 w-3.5", example.color)} />
              </div>
              <div className="text-left">
                <p className="text-sm font-medium">{example.name}</p>
                <p className="text-xs text-muted-foreground">{example.description}</p>
              </div>
            </div>
            <Search className="h-3.5 w-3.5 opacity-50" />
          </Button>
        ))}
      </div>
    </div>
  );
};

export default QuickActions;
