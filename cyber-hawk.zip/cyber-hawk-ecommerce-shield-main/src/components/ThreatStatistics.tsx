
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ThreatAnalysis, ThreatLevel } from '@/utils/threatDetection';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LabelList, Cell } from 'recharts';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { cn } from '@/lib/utils';
import { BarChart2 } from 'lucide-react';

interface ThreatStatisticsProps {
  history: ThreatAnalysis[];
}

const ThreatStatistics: React.FC<ThreatStatisticsProps> = ({ history }) => {
  // Skip rendering if no history
  if (!history || history.length === 0) {
    return null;
  }

  // Count threat levels
  const threatCounts = history.reduce((counts, item) => {
    counts[item.threatLevel] = (counts[item.threatLevel] || 0) + 1;
    return counts;
  }, {} as Record<ThreatLevel, number>);

  // Prepare data for the chart
  const chartData = [
    { name: 'High', value: threatCounts.high || 0, color: 'var(--security-high)' },
    { name: 'Medium', value: threatCounts.medium || 0, color: 'var(--security-medium)' },
    { name: 'Low', value: threatCounts.low || 0, color: 'var(--security-low)' },
    { name: 'Safe', value: threatCounts.safe || 0, color: 'var(--security-safe)' }
  ];

  // Count types of threats
  const threatTypeMap: Record<string, number> = {};
  history.forEach(item => {
    item.threatTypes.forEach(type => {
      threatTypeMap[type] = (threatTypeMap[type] || 0) + 1;
    });
  });

  // Convert threat types to chart data format, sorted by frequency
  const threatTypeData = Object.entries(threatTypeMap)
    .map(([name, value]) => ({ name: formatThreatType(name), value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 5); // Top 5 most common types

  // Helper to format threat type names
  function formatThreatType(type: string): string {
    return type
      .split('-')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }

  const chartConfig = {
    high: { theme: { light: 'var(--security-high)', dark: 'var(--security-high)' } },
    medium: { theme: { light: 'var(--security-medium)', dark: 'var(--security-medium)' } },
    low: { theme: { light: 'var(--security-low)', dark: 'var(--security-low)' } },
    safe: { theme: { light: 'var(--security-safe)', dark: 'var(--security-safe)' } },
  }

  return (
    <Card className="w-full max-w-3xl mt-8 border-secondary bg-card/50 card-hover-effect animate-fade-slide-in">
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <BarChart2 className="h-5 w-5 text-primary" />
          <div>
            <CardTitle className="text-lg">Threat Statistics</CardTitle>
            <CardDescription>
              Analysis of {history.length} scanned URLs
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="grid gap-6">
        <div>
          <h4 className="text-sm font-medium mb-3">Threat Level Distribution</h4>
          <div className="h-[180px]">
            <ChartContainer
              config={chartConfig}
              className="w-full rounded-lg border p-1 border-border/50"
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                  <XAxis dataKey="name" axisLine={false} tickLine={false} />
                  <YAxis hide />
                  <ChartTooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="rounded-lg border bg-background p-2 shadow-md">
                            <div className="grid grid-cols-2 gap-2">
                              <div className="flex items-center gap-1">
                                <div 
                                  className="h-2 w-2 rounded" 
                                  style={{ backgroundColor: payload[0].payload.color }}
                                />
                                <span className="text-[0.70rem] font-semibold uppercase">
                                  {payload[0].payload.name}
                                </span>
                              </div>
                              <span className="text-[0.70rem] font-bold text-right">
                                {payload[0].value} URLs
                              </span>
                            </div>
                          </div>
                        );
                      }
                      
                      return null;
                    }}
                  />
                  <Bar dataKey="value" radius={[4, 4, 0, 0]} maxBarSize={60}>
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                    <LabelList dataKey="value" position="top" fill="gray" fontSize={12} />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </div>
        </div>

        {threatTypeData.length > 0 && (
          <div>
            <h4 className="text-sm font-medium mb-3">Common Threat Types</h4>
            <div className="h-[180px]">
              <ChartContainer
                config={chartConfig}
                className="w-full rounded-lg border p-1 border-border/50"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={threatTypeData} layout="vertical" margin={{ top: 5, right: 30, left: 70, bottom: 5 }}>
                    <XAxis type="number" hide />
                    <YAxis 
                      type="category" 
                      dataKey="name" 
                      axisLine={false} 
                      tickLine={false}
                      width={65}
                      style={{ fontSize: '0.75rem' }}
                    />
                    <ChartTooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          return (
                            <div className="rounded-lg border bg-background p-2 shadow-md">
                              <div className="grid grid-cols-2 gap-2">
                                <span className="text-[0.70rem] font-semibold uppercase">
                                  {payload[0].payload.name}
                                </span>
                                <span className="text-[0.70rem] font-bold text-right">
                                  {payload[0].value} URLs
                                </span>
                              </div>
                            </div>
                          );
                        }
                        
                        return null;
                      }}
                    />
                    <Bar 
                      dataKey="value" 
                      barSize={12} 
                      radius={[0, 4, 4, 0]} 
                      fill="var(--primary)"
                    >
                      <LabelList dataKey="value" position="right" fill="gray" fontSize={12} />
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ThreatStatistics;
